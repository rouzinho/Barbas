import operator
import os
import urllib2
from pytagcloud import create_tag_image, make_tags
from pytagcloud.lang.counter import get_tag_counts
import pygame
from pygame.locals import *
from roundup.backends.indexer_common import STOPWORDS
import requests, collections, bs4
with open("tag.txt") as file:
	Data1 = file.read().lower()
	Data = Data1.split()
two_words = [' '.join(ws) for ws in zip(Data, Data[1:])]
wordscount = {w:f for w, f in collections.Counter(two_words).most_common() if f > 5}
sorted_wordscount = sorted(wordscount.iteritems(), key=operator.itemgetter(1),reverse=True)

from pytagcloud import create_tag_image, create_html_data, make_tags, LAYOUT_HORIZONTAL, LAYOUTS, LAYOUT_MIX, LAYOUT_VERTICAL, LAYOUT_MOST_HORIZONTAL, LAYOUT_MOST_VERTICAL
from pytagcloud.colors import COLOR_SCHEMES
from pytagcloud.lang.counter import get_tag_counts

tags = make_tags(get_tag_counts(Data1)[:50],maxsize=260)
create_tag_image(tags,'nuage.png', size=(800,600), background=(0, 0, 0, 255), layout=LAYOUT_MIX, fontname='Lobster', rectangular=False)
pygame.init()

fenetre = pygame.display.set_mode((800,600))

fond = pygame.image.load("nuage.png")
fenetre.blit(fond, (0,0))

pygame.display.flip()

continuer = 1

while continuer:
	continuer = int(input())
