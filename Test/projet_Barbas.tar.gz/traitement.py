# -*- coding: cp1252 -*-

#Voici la fonction qui permet de traiter des donn�es g�n�r�es
def compte_reponses() :
    f = open('sms.txt', 'r')
    t = f.readlines()
    f.close
    #print(t)
    f = open('modalites.txt', 'r')
    reponses = f.readlines()
    f.close
    reponses[:] = (value for value in reponses if value != '\n' )
    #print(reponses)
    compte = []
    for i in reponses :
        compte.append(0)
    print(compte)
    w={}
    #Dans cette boucle on stocke les r�ponses dans le dictionnaire w :
    for i in t :
        duet = i.split(' ')
        if duet[0].lower() in reponses :
            if duet[0] not in w :
                w[duet[0]]=duet[1].lower()
    #Ici on compte les scores pour chaque r�ponse :
    for i in w :
        for j in range(0,len(reponses)) :
            if w[i]==reponses[j] :
                compte[j]+=1
    resultats = []
    for i in range(0,len(reponses)) :
        resultats.append(reponses[i][:-1])
        resultats.append(compte[i])
    return resultats
    
test = compte_reponses()
#print(test)
