# PROBLEMES RESOLUS :
# - affichage bloquant l'execution
# - affichage de fenetre pour chaque boucle
# - probleme de rafraichissement de la fenetre entre chaque boucle


import time
import numpy as np
from matplotlib import pyplot as plt
from compte import *


def affichage(titre):

	OX = []
	OY = []
	fig = plt.figure()
	plt.title(titre)
	width = .35
	colors = ['yellowgreen', 'gold', 'lightskyblue', 'lightcoral']
	ecriture()
	try :
		with open('donnees.txt', 'r') as openedFile :
			for line in openedFile :
			    tab = line.split()
			    OY.append(int(tab[0]))
			    OX.append(str(tab[1]))
	except IOError :
		print("IOError!")

	ind = np.arange(len(OY))
	plt.bar(ind, OY,color=colors,align='center')
	plt.xticks(ind, OX)

	while 0<1:
		#print("AVANT")	
		plt.show(block=False)
		fig.set_canvas(fig.canvas)
		fig.canvas.draw()
		plt.cla()
		time.sleep(2)
		#print("APRES")

		OX = []
		OY = []
		ecriture()
		try :
			with open('donnees.txt', 'r') as openedFile:
				for line in openedFile:
					tab = line.split()
					OY.append(int(tab[0]))
					OX.append(str(tab[1]))
		except IOError :
		    print("IOError!")

		plt.title(titre)	
		plt.bar(ind, OY,color=colors,align='center')
		plt.xticks(ind, OX)

#FIN DE LA DEFINITION DE LA FONCTION Affichage(titre)
#affichage('Le sondage sms a t-il un avenir?')
	
	



