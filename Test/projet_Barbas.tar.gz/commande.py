def commande(com):
	line = com.split()
	if line[1] == "creer"
		
