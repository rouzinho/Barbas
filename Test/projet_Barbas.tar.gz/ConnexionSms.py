#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  FirstRead.py - Programme rudimentaire pour tester la communication 
#                 avec le SIM900 en Python
#
#  Envoi une commande AT sur le SIM900 et attend une réponse (entre 
#  autre le OK).
#
#  Le module SIM900 doit donc être actif, le plus simple est de le 
#  préparer et l'initialiser avec PuTTY puis de déconnecter Putty 
#  pour permettre a ce charmant programme de faire ses essai.
#  
#  Copyright 2013 Meurisse D. pour MCHobby.be
#     MCHobby - vente de kit et composant pour Arduino/Raspberry Pi, etc 
#     <info@MCHobby.be> CC-BY-SA   
#  
import serial,time,string
	

def main():

	ser = serial.Serial( 
			port = '/dev/ttyAMA0', \
			baudrate = 115200, \
			parity=serial.PARITY_NONE, \
			stopbits=serial.STOPBITS_ONE, \
			bytesize = serial.EIGHTBITS, \
			timeout = 0.100 )

	ser.open()
	fichier = open("data.txt","a")
	numero = ""
	vote = ""
	print( "connected to: " + ser.portstr )
	
	#ser.write( "AT"+chr(13) )
	
	#line = ser.readline()
	#print( line )
	#line = ser.readline()
	#print( line )
	lines = ser.readlines()
	lines =""
	if ser.isOpen():
		while True:
			lines = ser.readlines()
			if lines:
				print(lines)	
				numero = lines[1]
				vote = lines[2]
				numero = numero[7:19]
				print(numero)
				print(vote)
				fichier.write(numero)
				fichier.write(" ")
				fichier.write(vote)
				#fichier.write("\n")
			
				
		ser.close();

	return 0

if __name__ == '__main__':
	main()
