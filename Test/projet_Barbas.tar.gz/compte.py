def compte_oui() :
	f = open('sms.txt', 'r')
	t = f.readlines()
	f.close
	i = len(t)
	j = 0
	dico =[]
	while j <= i-1:
		mot = t[j]
		mot = mot.split()
		if t[j] != "\r\n":
			dico.append(mot[1])
		j = j+1
	nb = dico.count("Oui")
	nb = nb + dico.count("oui")
	nb = nb + dico.count("OUI")
	
	return nb
	
def compte_non() :
	f = open('sms.txt', 'r')
	t = f.readlines()
	f.close
	i = len(t)
	j = 0
	dico =[]
	while j <= i-1:
		mot = t[j]
		mot = mot.split()
		if t[j] != "\r\n":
			dico.append(mot[1])
		j = j+1
	nb = dico.count("Non")
	nb = nb + dico.count("non")
	nb = nb + dico.count("NON")
	
	return nb
	
def compte_pas() :
	f = open('sms.txt', 'r')
	t = f.readlines()
	f.close
	i = len(t)
	j = 0
	dico =[]
	while j <= i-1:
		mot = t[j]
		mot = mot.split()
		if t[j] != "\r\n":
			dico.append(mot[1])
		j = j+1
	nb = dico.count("Bof")
	nb = nb + dico.count("bof")
	nb = nb + dico.count("BOF")
	
	return nb

def ecriture():
	f = open('donnees.txt','w')
	oui = compte_oui()
	f.write(str(oui))
	f.write(" ")
	f.write("OUI")
	f.write("\n")
	non = compte_non()
	f.write(str(non))
	f.write(" ")
	f.write("NON")
	f.write("\n")
	bof = compte_pas()
	f.write(str(bof))
	f.write(" ")
	f.write("BOF")
	f.write("\n")
	f.close

