#!/usr/bin/env python
		
from EcouteSMS import *
from interface import *
import threading

def main():
	
	sur = EcouteSMS()
	sur.start()
	t = "Le projet est il innovant ?"
	affichage(t)

	return 0

if __name__ == '__main__':
	main()

